<?php
/*
Plugin Name: Grupos Vitopel
Plugin URI: https://joanmorales.com
Description: Plugin para asignar usuarios a grupos y ocultar entradas basado en el grupo.
Version: 1.0
Author: Joan Morales
Author URI: https://joanmorales.com
*/

// Registro de la página de opciones y los campos de configuración
function grupos_une_menu() {
    add_options_page('Grupos Vitopel', 'Grupos Vitopel', 'manage_options', 'grupos-une', 'grupos_une_opciones');
}
add_action('admin_menu', 'grupos_une_menu');

function grupos_une_opciones() {
    ?>
    <div class="wrap">
        <h1>Grupos Vitopel</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('grupos_une');
            do_settings_sections('grupos-une');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function grupos_une_configuracion() {
    register_setting('grupos_une', 'grupos_une');
    add_settings_section(
        'grupos_une_seccion', 
        'Gestiona tus grupos', 
        'grupos_une_seccion_callback', 
        'grupos-une'
    );
    add_settings_field(
        'grupos_une_campo',
        'Nombres de los grupos', 
        'grupos_une_campo_callback', 
        'grupos-une', 
        'grupos_une_seccion'
    );
}
add_action('admin_init', 'grupos_une_configuracion');

function grupos_une_seccion_callback() {
    echo 'Agrega, elimina o edita tus grupos.';
}

function grupos_une_campo_callback() {
    $grupos = get_option('grupos_une', []);
    
    echo '<style>
        .grupo-entry {
            margin-bottom: 10px;
        }
        .grupo-entry input {
            margin-right: 10px;
        }
        .grupo-entry input[disabled] {
            background-color: #ccc;
        }
        .grupo-entry .hidden {
            display: none;
        }
    </style>';
    
    echo '<div id="grupos_une_wrapper">';
    foreach ($grupos as $grupo) {
        $is_disabled = in_array(trim($grupo), ["Buenos Aires - Todos", "Totoral - Todos"]);
        $disabled_attr = $is_disabled ? 'disabled' : '';
        $remove_button = $is_disabled ? '' : "<button type='button' class='remove_grupo'>Eliminar</button>";
        
        echo "<div class='grupo-entry'>";
        // Si el campo está deshabilitado, imprimir también un campo oculto para conservar el valor
        if ($is_disabled) {
            echo "<input type='hidden' name='grupos_une[]' value='" . esc_attr(trim($grupo)) . "' />";
        }
        echo "<input type='text' name='grupos_une[]' value='" . esc_attr(trim($grupo)) . "' {$disabled_attr} />";
        echo $remove_button;
        echo "</div>";
    }
    echo '</div>';
    echo '<button id="add_grupo">Agregar otro grupo</button>';
    echo '<script>
        jQuery(document).ready(function($) {
            $("#add_grupo").click(function(e) {
                e.preventDefault();
                $("#grupos_une_wrapper").append(\'<div class="grupo-entry"><input type="text" name="grupos_une[]"/><button type="button" class="remove_grupo">Eliminar</button></div>\');
            });
            $("#grupos_une_wrapper").on("click", ".remove_grupo", function(e) {
                e.preventDefault();
                $(this).parent(".grupo-entry").remove();
            });
        });
    </script>';
}



function grupos_une_campos_perfil($user) {
    $grupos = get_option('grupos_une', ['Todos']);
    $grupos_usuario = get_user_meta($user->ID, 'grupo_une', false);
    ?>
    <h3>Grupos Vitopel</h3>
    <table class="form-table">
        <tr>
            <th><label for="grupo_une">Grupos</label></th>
            <td>
                <?php
                foreach ($grupos as $grupo) {
                    $grupo_trimmed = esc_attr(trim($grupo));
                    $isChecked = in_array($grupo_trimmed, $grupos_usuario) ? 'checked' : '';
                    echo "<label><input type=\"checkbox\" name=\"grupo_une[]\" value=\"$grupo_trimmed\" $isChecked> " . esc_html($grupo_trimmed) . "</label><br>";
                }
                ?>
            </td>
        </tr>
    </table>
    <?php
}

add_action('show_user_profile', 'grupos_une_campos_perfil');
add_action('edit_user_profile', 'grupos_une_campos_perfil');

function grupos_une_guardar_campos_perfil($user_id) {
    if (!current_user_can('edit_user', $user_id)) {
        return false;
    }
    
    delete_user_meta($user_id, 'grupo_une');
    if (!empty($_POST['grupo_une'])) {
        foreach ($_POST['grupo_une'] as $grupo) {
            add_user_meta($user_id, 'grupo_une', $grupo);
        }
    }
    
    // Actualizar la opción de grupos en la base de datos basada en los datos del formulario
    if (isset($_POST['grupos_une'])) {
        $grupos_formulario = array_map('trim', $_POST['grupos_une']);
        $grupos_formulario = array_filter($grupos_formulario, function($grupo) {
            return !empty($grupo);
        });

        update_option('grupos_une', $grupos_formulario);
    }
}
add_action('personal_options_update', 'grupos_une_guardar_campos_perfil');
add_action('edit_user_profile_update', 'grupos_une_guardar_campos_perfil');

function grupos_une_metabox_entrada() {
    add_meta_box('grupos_une_metabox', 'Grupos Vitopel', 'grupos_une_metabox_entrada_callback', 'post');
}
add_action('add_meta_boxes', 'grupos_une_metabox_entrada');

function grupos_une_enqueue_scripts() {
    wp_enqueue_script('jquery');
}
add_action('admin_enqueue_scripts', 'grupos_une_enqueue_scripts');

function grupos_une_metabox_entrada_callback($post) {
    // Aquí asumimos que has actualizado la opción 'grupos_une' para incluir los nuevos grupos.
    $grupos = get_option('grupos_une', ['Buenos Aires - Todos', 'Totoral - Todos']);
    $grupos_entrada = get_post_meta($post->ID, 'grupo_une', false);

    // Recorremos cada grupo y creamos un checkbox para él.
    foreach ($grupos as $grupo) {
        $grupo_trimmed = esc_attr(trim($grupo));
        $isChecked = in_array($grupo_trimmed, $grupos_entrada) ? 'checked' : '';
        echo "<label><input type=\"checkbox\" class=\"grupo-checkbox\" name=\"grupo_une[]\" value=\"$grupo_trimmed\" $isChecked> " . esc_html($grupo_trimmed) . "</label><br>";
    }
    ?>
   <script>
     jQuery(document).ready(function($) {
        // Evento al cambiar cualquier checkbox.
        $('.grupo-checkbox').change(function() {
            // Determina el valor del checkbox actual.
            var valorActual = $(this).val();
            
            // Si el checkbox actual no es 'Buenos Aires - Todos' ni 'Totoral - Todos' y está marcado
            if (this.checked && valorActual !== 'Buenos Aires - Todos' && valorActual !== 'Totoral - Todos') {
                // Deselecciona 'Buenos Aires - Todos' y 'Totoral - Todos'.
                $('.grupo-checkbox').filter('[value="Buenos Aires - Todos"], [value="Totoral - Todos"]').prop('checked', false);
            }
            // Si el checkbox actual es 'Buenos Aires - Todos' o 'Totoral - Todos'
            else if (this.checked && (valorActual === 'Buenos Aires - Todos' || valorActual === 'Totoral - Todos')) {
                // Deselecciona todos los checkboxes que no sean 'Buenos Aires - Todos' ni 'Totoral - Todos'.
                $('.grupo-checkbox').not('[value="Buenos Aires - Todos"], [value="Totoral - Todos"]').prop('checked', false);
            }
        });
    });
    </script>


    <?php
}


function grupos_une_guardar_metabox_entrada($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    delete_post_meta($post_id, 'grupo_une');
    if (!empty($_POST['grupo_une'])) {
        foreach ($_POST['grupo_une'] as $grupo) {
            add_post_meta($post_id, 'grupo_une', $grupo);
        }
    }
}
add_action('save_post', 'grupos_une_guardar_metabox_entrada');

/***filtro para elementor****/
// Filtro para Elementor
add_action( 'elementor/query/filters_grupo_une', function( $query ) {
    if ( is_user_logged_in() ) {
        $user = wp_get_current_user();
        
        // Si el usuario es un administrador, no aplicar el filtro
        if (user_can($user, 'manage_options')) {
            return;
        }

        $user_grupo_une = get_user_meta( $user->ID, 'grupo_une', false );
        $meta_query = array('relation' => 'OR');
        foreach ($user_grupo_une as $grupo) {
            // Solo añadir al meta_query los grupos 'Buenos Aires - Todos' y 'Totoral - Todos'.
            if ($grupo === 'Buenos Aires - Todos' || $grupo === 'Totoral - Todos') {
                $meta_query[] = array(
                    'key' => 'grupo_une',
                    'value' => $grupo,
                    'compare' => '='
                );
            }
        }
        // Eliminamos la referencia al antiguo grupo 'todos'.
        // Actualizamos la consulta con el nuevo meta_query
        $query->set( 'meta_query', $meta_query );
    }
} );


/**filtrado para el resto de wordpress**/
add_action('pre_get_posts', function ($query) {
    // Comprobamos si es la consulta principal, y si estamos en un archivo y si el usuario está logueado
    if ($query->is_main_query() && !is_admin() && $query->is_archive() && is_user_logged_in()) {
        // Obtenemos el usuario actual
        $user = wp_get_current_user();
        
        // Si el usuario es un administrador, no aplicamos el filtro
        if (user_can($user, 'manage_options')) {
            return;
        }

        // Obtenemos los grupos a los que pertenece el usuario
        $user_grupo_une = get_user_meta($user->ID, 'grupo_une', false);
        $meta_query = array('relation' => 'OR');
        foreach ($user_grupo_une as $grupo) {
            // Asegúrate de que solo los grupos 'Buenos Aires - Todos' y 'Totoral - Todos' sean añadidos.
            if ($grupo === 'Buenos Aires - Todos' || $grupo === 'Totoral - Todos') {
                $meta_query[] = array(
                    'key' => 'grupo_une',
                    'value' => $grupo,
                    'compare' => '='
                );
            }
        }
        // Si el usuario no pertenece a ninguno de los grupos 'Todos', puedes decidir cómo manejarlo,
        // por ejemplo, no añadir ningún otro filtro, o manejar un caso por defecto.
        
        // Actualizamos la consulta con el nuevo meta_query
        $query->set('meta_query', $meta_query);
    }
});


function asignar_grupo_por_defecto($user_id) {
    add_user_meta($user_id, 'grupo_une', 'Buenos Aires - Todos');
    add_user_meta($user_id, 'grupo_une', 'Totoral - Todos');
}

add_action('user_register', 'asignar_grupo_por_defecto');

/**Restriccion para las paginas**/
// Agregar un metabox en las páginas
/*function grupos_une_metabox_pagina() {
    add_meta_box('grupos_une_metabox', 'Grupos Vitopel', 'grupos_une_metabox_entrada_callback', 'page');
}
add_action('add_meta_boxes', 'grupos_une_metabox_pagina');

function grupos_une_restringir_acceso_paginas() {
    global $post;
    
    if(is_page() && isset($post->ID)) {
        $grupos_pagina = get_post_meta($post->ID, 'grupo_une', false);
        $grupos_usuario = get_user_meta(get_current_user_id(), 'grupo_une', false);

        if(!empty($grupos_pagina)) {
            $tiene_acceso = array_intersect($grupos_pagina, $grupos_usuario);
            
            if(empty($tiene_acceso)) {
                // Redireccionar al usuario a una página de error o inicio si no tiene acceso
                wp_redirect(home_url());
                exit;
            }
        }
    }
}
add_action('template_redirect', 'grupos_une_restringir_acceso_paginas');*/


/***mostrar los permisos en la lista de entradas***/
function grupos_une_columna_permisos($columns) {
    $nuevas_columnas = array();

    foreach ($columns as $key => $title) {
        if ($key == 'tags') { 
            // Agregar nuestra columna personalizada antes de las etiquetas.
            $nuevas_columnas['grupo_permisos'] = 'Permisos de Grupos';
        }
        $nuevas_columnas[$key] = $title;
    }

    return $nuevas_columnas;
}
add_filter('manage_posts_columns', 'grupos_une_columna_permisos');


function grupos_une_mostrar_permisos_columna($column, $post_id) {
    if ($column == 'grupo_permisos') {
        $grupos = get_post_meta($post_id, 'grupo_une', false);
        if(!empty($grupos)) {
            // Aquí, simplemente estoy mostrando los grupos separados por comas. 
            // Puedes ajustar el formato como desees.
            echo implode(", ", $grupos);
        } else {
            echo "Sin permisos específicos";
        }
    }
}
add_action('manage_posts_custom_column', 'grupos_une_mostrar_permisos_columna', 10, 2);
?>