/*jQuery(document).ready(function($) {
    // Detectar cuando se selecciona un checkbox de grupo
    $("input[name='grupo_une[]']").change(function() {
        if ($(this).val() == "todos") {
            // Si se selecciona "Todos", desmarcar los demás
            if ($(this).is(":checked")) {
                $("input[name='grupo_une[]']").not(this).prop('checked', false);
            }
        } else {
            // Si se selecciona otro grupo, desmarcar "Todos"
            $("input[name='grupo_une[]'][value='todos']").prop('checked', false);
        }
    });
});*/

jQuery(document).ready(function($) {
    // Detectar cuando se selecciona un checkbox de grupo
    $("input[name='grupo_une[]']").change(function() {
        var val = $(this).val();
        // Comprobar si el valor seleccionado es uno de los grupos generales "Todos"
        if (val === "Buenos Aires - Todos" || val === "Totoral - Todos") {
            // Si se selecciona un grupo "Todos X", desmarcar todos los otros checkboxes
            $("input[name='grupo_une[]']").each(function() {
                if ($(this).val() !== val) {
                    $(this).prop('checked', false);
                }
            });
        } else {
            // Si se selecciona otro grupo que no es un "Todos X", desmarcar los grupos generales "Todos"
            $("input[name='grupo_une[]']").each(function() {
                if ($(this).val() === "Buenos Aires - Todos" || $(this).val() === "Totoral - Todos") {
                    $(this).prop('checked', false);
                }
            });
        }
    });
});

